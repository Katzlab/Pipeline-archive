// $Id: constantSemphyDistance.cpp 409 2005-06-28 13:12:24Z ninio $

#include "constantSemphyDistance.h"

// this file intently left blank.


