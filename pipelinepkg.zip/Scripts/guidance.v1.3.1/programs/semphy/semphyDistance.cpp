// $Id: semphyDistance.cpp 409 2005-06-28 13:12:24Z ninio $

#include "semphyDistance.h"

semphyDistance::~semphyDistance() {}

