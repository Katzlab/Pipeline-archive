// $Id: khTest.h 962 2006-11-07 15:13:34Z privmane $

#ifndef ___KH_TEST
#define ___KH_TEST

void makekhTest(const VVdouble & likelihoodVal, MDOUBLE diffNumOfFreeParam=0);


#endif

